#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Celdas
//
// 0 - Agua
// 1 - Barco
// 2 - Bomba cayo en agua
// 3 - Bomba impacto en barco

int c11;
int c21;
int c31;
int c41;
int c12;
int c22;
int c32;
int c42;
int c13;
int c23;
int c33;
int c43;
int c14;
int c24;
int c34;
int c44;


int bombas;

int cuentaBarcos()
{
   int total;
   
   total = 0;
    
   if(c11 == 1) { total = total + 1; }
   if(c12 == 1) { total = total + 1; }
   if(c13 == 1) { total = total + 1; }
   if(c14 == 1) { total = total + 1; }
   if(c21 == 1) { total = total + 1; }
   if(c22 == 1) { total = total + 1; }
   if(c23 == 1) { total = total + 1; }
   if(c24 == 1) { total = total + 1; }
   if(c31 == 1) { total = total + 1; }
   if(c32 == 1) { total = total + 1; }
   if(c33 == 1) { total = total + 1; }
   if(c34 == 1) { total = total + 1; }
   if(c41 == 1) { total = total + 1; }
   if(c42 == 1) { total = total + 1; }
   if(c43 == 1) { total = total + 1; }
   if(c44 == 1) { total = total + 1; }
   
   return total;
   
}


int obtenCelda(int x, int y)
{
    if(x == 0 && y == 0) { return c11; }
    else if(x == 1 && y == 0) { return c21; }
    else if(x == 2 && y == 0) { return c31; }
    else if(x == 3 && y == 0) { return c41; }
    else if(x == 0 && y == 1) { return c12; }
    else if(x == 1 && y == 1) { return c22; }
    else if(x == 2 && y == 1) { return c32; }
    else if(x == 3 && y == 1) { return c42; }
    else if(x == 0 && y == 2) { return c13; }
    else if(x == 1 && y == 2) { return c23; }
    else if(x == 2 && y == 2) { return c33; }
    else if(x == 3 && y == 2) { return c43; }
    else if(x == 0 && y == 3) { return c14; }
    else if(x == 1 && y == 3) { return c24; }
    else if(x == 2 && y == 3) { return c34; }
    else // (x == 3 && y == 3)
    { return c44; }
}

void ponCelda(int x, int y, int v)
{
    if(x == 0 && y == 0) { c11 = v; }
    else if(x == 1 && y == 0) { c21 = v; }
    else if(x == 2 && y == 0) { c31 = v; }
    else if(x == 3 && y == 0) { c41 = v; }
    else if(x == 0 && y == 1) { c12 = v; }
    else if(x == 1 && y == 1) { c22 = v; }
    else if(x == 2 && y == 1) { c32 = v; }
    else if(x == 3 && y == 1) { c42 = v; }
    else if(x == 0 && y == 2) { c13 = v; }
    else if(x == 1 && y == 2) { c23 = v; }
    else if(x == 2 && y == 2) { c33 = v; }
    else if(x == 3 && y == 2) { c43 = v; }
    else if(x == 0 && y == 3) { c14 = v; }
    else if(x == 1 && y == 3) { c24 = v; }
    else if(x == 2 && y == 3) { c34 = v; }
    else //(x == 3 && y == 3)
    { c44 = v; }
}

void iniciaPartida()
{
    ponCelda(0, 0, 0);
    ponCelda(1, 0, 0);
    ponCelda(2, 0, 0);
    ponCelda(3, 0, 0);
    ponCelda(0, 1, 0);
    ponCelda(1, 1, 0);
    ponCelda(2, 1, 0);
    ponCelda(3, 1, 0);
    ponCelda(0, 2, 0);
    ponCelda(1, 2, 0);
    ponCelda(2, 2, 0);
    ponCelda(3, 2, 0);
    ponCelda(0, 3, 0);
    ponCelda(1, 3, 0);
    ponCelda(2, 3, 0);
    ponCelda(3, 3, 0);
    
    int posX;
    int posY;
    
    while(cuentaBarcos() != 3)
    {
        posX = rand() % 4;
        posY = rand() % 4;
        
        ponCelda(posX, posY, 1);
    }
    
    bombas = 6;
    
    
}

void imprimeCelda(int c, int mostrarBarcos)
{
    if(c == 0) { printf(" |"); }
    else if(c == 1 && !mostrarBarcos) { printf(" |"); }
    else if(c == 1 && mostrarBarcos) { printf("B|"); }
    else if(c == 2) { printf("X|"); }
    else // c == 3
    { printf("V|"); }
    
}

void imprimeTablero(int mostrarBarcos)
{
    printf(" X 1 2 3 4\n");
    printf("Y +-+-+-+-+\n");
    printf(" 1|");
    imprimeCelda(c11, mostrarBarcos);
    imprimeCelda(c21, mostrarBarcos);
    imprimeCelda(c31, mostrarBarcos);
    imprimeCelda(c41, mostrarBarcos);
    printf("\n");
    printf("  +-+-+-+-+\n");
    printf(" 2|");
    imprimeCelda(c12, mostrarBarcos);
    imprimeCelda(c22, mostrarBarcos);
    imprimeCelda(c32, mostrarBarcos);
    imprimeCelda(c42, mostrarBarcos);
    printf("\n");
    printf("  +-+-+-+-+\n");
    printf(" 3|");
    imprimeCelda(c13, mostrarBarcos);
    imprimeCelda(c23, mostrarBarcos);
    imprimeCelda(c33, mostrarBarcos);
    imprimeCelda(c43, mostrarBarcos);
    printf("\n");
    printf("  +-+-+-+-+\n");
    printf(" 4|");
    imprimeCelda(c14, mostrarBarcos);
    imprimeCelda(c24, mostrarBarcos);
    imprimeCelda(c34, mostrarBarcos);
    imprimeCelda(c44, mostrarBarcos);
    printf("\n");
    printf("  +-+-+-+-+\n");
}




void main()
{
	FILE* fichero;
    int opcion;
    
    srand(time(0));
    
    opcion = -1;
    
    iniciaPartida();

    printf("=====================\n");
    printf("  Hundir la flota \n");
    printf("=====================\n");

    while(opcion != 0 && cuentaBarcos() != 0 && bombas > 0)
    {
        
        imprimeTablero(0);
        
        printf("1 - Reiniciar partida\n");
        printf("2 - Continuar\n");
		printf("3 - Guardar partida\n");
		printf("4 - Cargar partida\n");
        printf("0 - Salir\n");

        scanf("%d", &opcion);
        
        if(opcion == 1)
        {
            iniciaPartida();
        }
        else if(opcion == 2)
        {
            int x;
            int y;
            int hechoX;
            int hechoY;
            int hecho;
            int valor;
            
            printf("Te quedan %d bombas\n", bombas);
            
            hecho = 0;
            
            while(!hecho)
            {
                hechoX = 0;
                hechoY = 0;   

                while(!hechoX)
                {
                    printf("Celda X?");
                    scanf("%d", &x);
                    if(x - 1 >= 0 && x - 1 <= 3) { hechoX = 1; }
                    else { printf("Tienes que poner un numero del 0 al 3\n"); }
                }

                while(!hechoY)
                {
                    printf("Celda Y?");
                    scanf("%d", &y);
                    if(y - 1 >= 0 && y - 1 <= 3) { hechoY = 1; }
                    else { printf("Tienes que poner un numero del 0 al 3\n"); }
                }
                
                valor = obtenCelda(x - 1, y - 1);
                
                if(valor == 0)
                {
                   printf("Agua!\n");
                   ponCelda(x - 1, y - 1, 2);
                   bombas = bombas - 1;
                   hecho = 1;
                }
                else if(valor == 1)
                {
                   printf("Hundido!\n");
                   ponCelda(x - 1, y - 1, 3);
                   bombas = bombas - 1;
                   hecho = 1;
                }
                else { printf("Ya has disparado a esa posicion\n"); }
                
            }
            

        }
		else if (opcion == 3)
		{
			fichero = fopen("partida.dat", "wb");

			fwrite(&c11, 4, 1, fichero);
			fwrite(&c21, 4, 1, fichero);
			fwrite(&c31, 4, 1, fichero);
			fwrite(&c41, 4, 1, fichero);
			fwrite(&c12, 4, 1, fichero);
			fwrite(&c22, 4, 1, fichero);
			fwrite(&c32, 4, 1, fichero);
			fwrite(&c42, 4, 1, fichero);
			fwrite(&c13, 4, 1, fichero);
			fwrite(&c23, 4, 1, fichero);
			fwrite(&c33, 4, 1, fichero);
			fwrite(&c43, 4, 1, fichero);
			fwrite(&c14, 4, 1, fichero);
			fwrite(&c24, 4, 1, fichero);
			fwrite(&c34, 4, 1, fichero);
			fwrite(&c44, 4, 1, fichero);
			fwrite(&bombas, 4, 1, fichero);
	
			fclose(fichero);
	
			printf("Se ha guardado correctamente la partida\n");
	
		}
		
		else if (opcion == 4)
		{
			FILE* fichero;
	
			fichero = fopen("partida.dat", "rb");
	
			fread(&c11, 4, 1, fichero);
			fread(&c21, 4, 1, fichero);
			fread(&c31, 4, 1, fichero);
			fread(&c41, 4, 1, fichero);
			fread(&c12, 4, 1, fichero);
			fread(&c22, 4, 1, fichero);
			fread(&c32, 4, 1, fichero);
			fread(&c42, 4, 1, fichero);
			fread(&c13, 4, 1, fichero);
			fread(&c23, 4, 1, fichero);
			fread(&c33, 4, 1, fichero);
			fread(&c43, 4, 1, fichero);
			fread(&c14, 4, 1, fichero);
			fread(&c24, 4, 1, fichero);
			fread(&c34, 4, 1, fichero);
			fread(&c44, 4, 1, fichero);
			fread(&bombas, 4, 1, fichero);
			
			fclose(fichero);
			
			printf("Partida cargada correctamente!\n");
			
		}
		
        
    }
    
    if(opcion != 0)
    {
        imprimeTablero(1);
        
        if(cuentaBarcos() == 0) { printf("Ganaste!\n"); }
        else { printf("Perdiste!\n"); }
    }
    
}